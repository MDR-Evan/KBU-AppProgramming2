package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 앱 시작 시 기본 Fragment (예: 조회 화면)
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, new QueryStudentFragment())
                .commit();
    }
}
